namespace DAL;
using MySql.Data.MySqlClient;
using EmpCrud.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;
//using inbuilt, external Object Models

public class DBManager
{

    public static string conString = @"server=localhost;port=3306;user=root; password=Admin@000;database=db1";
    public  List<Employee> GetAllEmployees()
    {
        List<Employee> allEmployees = new List<Employee>();
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        string query = "SELECT * FROM Employee";
        try
        {
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = query;
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int Id = int.Parse(reader["Id"].ToString());
                string FirstName = reader["FirstName"].ToString();
                string LastName = reader["LastName"].ToString();
                // DateTime DateOfBirth =Convert.ToDateTime(reader["DateOfBirth"].DateTime);
                string Email = reader["Email"].ToString();
                float Salary = float.Parse(reader["Salary"].ToString());

                Employee employee = new Employee(Id, FirstName, LastName, Email, Salary);
                allEmployees.Add(employee);
            }
        }
        catch (Exception ee)
        {
            Console.WriteLine(ee.Message);
        }
        finally
        {
            con.Close();
        }

        return allEmployees;
    }

    public  bool Insert(int Id,string FirstName,string LastName,string Email,float Salary)
    {
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        string query = "INSERT INTO Employee values(@Id,@FirstName,@LastName,@Email,@Salary)";
        try
        {
            MySqlCommand cmd = new MySqlCommand(query,con);
            con.Open();

            cmd.Parameters.AddWithValue("@Id", Id);
            cmd.Parameters.AddWithValue("@FirstName", FirstName);
            cmd.Parameters.AddWithValue("@LastName", LastName);
            cmd.Parameters.AddWithValue("@Email", Email);
            cmd.Parameters.AddWithValue("@Salary", Salary);

            cmd.ExecuteNonQuery();
            return true;
            
        }
        catch (Exception ee)
        {
            Console.WriteLine(ee.Message);
        }
        finally
        {
            con.Close();
        }
        return false;

    }

    public  bool Update(int Id,string FirstName,string LastName,string Email,float Salary)
    {
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        string query = "UPDATE Employee SET FirstName=@FirstName,LastName=@LastName,Email=@Email,Salary=@Salary where Id=@Id";
        System.Console.WriteLine(Id+" : "+Email);
        try
        {
            MySqlCommand cmd = new MySqlCommand(query,con);
            con.Open();

            cmd.Parameters.AddWithValue("@Id", Id);
            cmd.Parameters.AddWithValue("@FirstName", FirstName);
            cmd.Parameters.AddWithValue("@LastName", LastName);
            cmd.Parameters.AddWithValue("@Email", Email);
            cmd.Parameters.AddWithValue("@Salary", Salary);

            cmd.ExecuteNonQuery();
            return true;
            
        }
        catch (Exception ee)
        {
            Console.WriteLine(ee.Message);
        }
        finally
        {
            con.Close();
        }
        return false;

    }

    public  bool Delete(int Id)
    {
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        string query = "DELETE FROM Employee WHERE Id=@Id";
        System.Console.WriteLine(Id+" deleted ");
        try
        {
            MySqlCommand cmd = new MySqlCommand(query,con);
            con.Open();

            cmd.Parameters.AddWithValue("@Id", Id);

            cmd.ExecuteNonQuery();
            return true;
            
        }
        catch (Exception ee)
        {
            Console.WriteLine(ee.Message);
        }
        finally
        {
            con.Close();
        }
        return false;

    }



}