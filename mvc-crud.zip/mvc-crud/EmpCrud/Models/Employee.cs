namespace EmpCrud.Models;

public class Employee{
    public int Id { get; set; }

   // [DisplayName("First Name")]
   // [Required]
    public string FirstName { get; set; }
   // [DisplayName("Last Name")]
    // [Required]
    public string LastName { get; set; }
    // [DisplayName(" DateOfBirth")]
    // [Required]
    // public DateTime DateOfBirth { get; set; }
   // [DisplayName(" Email")]
   //  [Required]
    public string Email { get; set; }
   // [DisplayName(" Salary")]
   //  [Required]
    public float Salary { get; set; }


    public Employee(int Id,string FirstName,string LastName,string Email,float Salary)
    {
        this.Id = Id;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.Email = Email;
        this.Salary = Salary;
        

    }
    // [notMapped]
    public string FullName
    {
        get { return FirstName + " " + LastName; }
    }


}