using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using EmpCrud.Models;
using DAL;
using BLL;

namespace EmpCrud.Controllers;

public class EmployeeController : Controller
{
    private readonly ILogger<EmployeeController> _logger;
    // private readonly ;

    public EmployeeController(ILogger<EmployeeController> logger)
    {
        _logger = logger;
    }

    [HttpGet]
    public IActionResult Insert()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Insert(int Id,string FirstName,string LastName,string Email,float Salary)
    {
        DBManager db = new DBManager();
        bool status =db.Insert(Id, FirstName, LastName, Email, Salary);

        if(status)
        {
            return RedirectToAction("Display");

        }
        else
        {
            return RedirectToAction("Error1");
        }
    }

    [HttpGet]
    public IActionResult Delete(int Id,string Email)
    {
        DBManager db = new DBManager();
        List<Employee> allEmployees = db.GetAllEmployees();
        var e = allEmployees.Find((Employee) => Employee.Id == Id);
        return View(e);
    }

    [HttpPost]
    public IActionResult Delete(int Id)
    {
        DBManager db = new DBManager();
        bool status = db.Delete(Id);
        System.Console.WriteLine(status);
        if(status)
        {
            return RedirectToAction("Display");

        }
        else
        {
            return RedirectToAction("Error1");
        }
    }

    [HttpGet]
    public IActionResult Update(int Id)
    {
        DBManager db = new DBManager();
        List<Employee> allEmployees = db.GetAllEmployees();
        var e = allEmployees.Find((Employee) => Employee.Id == Id);
        return View(e);
    }

    [HttpPost]
    public IActionResult Update(int Id,string FirstName,string LastName,string Email,float Salary)
    {
        DBManager db = new DBManager();
        bool status = db.Update(Id,FirstName, LastName, Email, Salary);
        System.Console.WriteLine(status);
        if(status)
        {
            return RedirectToAction("Display");

        }
        else
        {
            return RedirectToAction("Error1");
        }
    }
    [HttpGet]
    public IActionResult Display()
    {
        DBManager db = new DBManager();
        List<Employee> allEmployees = db.GetAllEmployees();
        ViewData["data"] = allEmployees;
        return View();
    }


    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
